#pragma once

enum transport_type
{
  tcp,
  udp
};
