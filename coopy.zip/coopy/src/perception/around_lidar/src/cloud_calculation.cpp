//本节点输入为前后左右四路激光点云,输出前后左右障碍物最近距离和前后纠偏误差

#define PCL_NO_PRECOMPILE

#include <ros/ros.h>
#include <ros/spinner.h>
#include "std_msgs/String.h"
#include "std_msgs/Float32MultiArray.h"
#include "sensor_msgs/PointCloud2.h"
#include <tf/transform_listener.h>
#include <geometry_msgs/PointStamped.h>
#include "pcl_conversions/pcl_conversions.h"
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/common/common.h>
#include <pcl_ros/transforms.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/filters/voxel_grid.h>
#include <geometry_msgs/PoseStamped.h>

#include "pointcloud_type.h"
#include "common/public.h"
#include <mqtt_comm/task.h>

#include "cloud_preprocess.h"
#include <vector>
#include <algorithm>

using namespace std;

ros::NodeHandle *nh;
ros::Publisher pub_agv_pose;
bool agv_in_flag=false, agv_all_in_flag=false;


float inside_err=999, front_err=999, back_err=999, inside_left_dis=999, inside_right_dis=999;
float front_obs_dis=999, back_obs_dis=999, right_obs_dis=999, left_obs_dis=999, inside_front_dis, inside_back_dis;
// PointCloud inside_cloud, front_cloud, back_cloud;

float agv_width=3, agv_length=6, agv_inside_width=2.105;
bool front_cloud_enable=true;  

mqtt_comm::task cur_task;
ros::Publisher pub_cloud_checkerr;

//  接收任务指令
void TaskCallback(const mqtt_comm::task::ConstPtr &msg)
{
    // ROS_ERROR("%s\n", msg->cmd.c_str());
    if (msg->cmd.find("task") != string::npos)
    {
        cur_task = *msg;
        cur_task.stamp = ros::Time::now();

        if(cur_task.path.size()>0)   // 判断使用前方点云还是后方点云作为纠偏数据
        {
            geometry_msgs::PointStamped target_map, target_base;
            target_map.header.frame_id="map";
            target_map.header.stamp=ros::Time::now();
            target_map.point.x=(cur_task.path.end()-1)->pointX;
            target_map.point.y=(cur_task.path.end()-1)->pointY;
 
            transformPoint("base_link", target_map, target_base);
            if(target_base.point.x>0)  front_cloud_enable=true;
            else front_cloud_enable=false; 

            // ROS_INFO("x=%.1f y=%.1f e=%d",target_base.point.x, target_base.point.y, front_cloud_enable);
        }
    }
}

// void PubAgvPos(PointCloud cloud)
// {
//     static TDataFilter filter_angle(10), filter_x(10), filter_y(10);
//     static PointCloud all_cloud;
//     static int count=0;

//     all_cloud+=cloud;
//     all_cloud.header=cloud.header;
//     count++;
//     if(count<2)  return;
    
//     TMinBoundingBox mbb("lidar_target");
//     mbb.Calculate(all_cloud, 0.2, -10, 10);
//     geometry_msgs::PoseStamped pose=mbb.pose, pose_map;
//     // transformPose("map",mbb.pose,pose_map);
                        
//     float angle = GetYawFromPose(pose);   
//     angle=filter_angle.GetValue(angle)-1.3/180*M_PI;
//     pose.pose.position.x=filter_x.GetValue(pose.pose.position.x);
//     pose.pose.position.y=filter_y.GetValue(pose.pose.position.y);

//     bool pub_enable=true; //(cur_task.cmd=="pick task" && back_obs_dis<0.5 && first_send);
    
//     //(cur_task.cmd=="pick task" || (cur_task.cmd=="move task" && agv_in_flag && first_send));
//     if(pub_enable)
//     {
//         float map_angle = GetYawFromPose(pose_map);
//         if(cur_task.path.size()>0)
//         {
//             float angle_err=fabs(cur_task.path[0].pointHA-map_angle*180/M_PI);
//             // printf("%.2f\n",angle_err);  
//             if(angle_err>90)  angle+=M_PI;
//         }

//         first_send=false;
//         pose.pose.orientation=tf::createQuaternionMsgFromYaw(angle);
//         pub_agv_pose.publish(pose);   
//         ROS_INFO("%.1f  %.2f %.2f", angle/M_PI*180.0, pose.pose.position.x, pose.pose.position.y);
//     }

//     all_cloud.clear();
//     count=0;
// }

// 根据商品车转运机器人内部的点云进行判断
void PointCloudInsideCallback(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    static TDataFilter filter_err(10);

    PointCloud cloud;
    pcl::fromROSMsg(*c_msg, cloud);

    inside_err=999;  inside_left_dis=inside_right_dis=999;
    agv_in_flag=agv_all_in_flag=false;

    if(cloud.size()>20)
    {
        //inside_cloud=Cloud_PassThrough(inside_cloud, -agv_length*0.5+0.1, agv_length*0.5-0.1, -agv_inside_width*0.5, -agv_inside_width*0.5, -0.6, -0.2);
        // inside_cloud=Cloud_RadiusFilter(icloud, 0.05, 3);
        pcl::PointXYZI cloud_min, cloud_max;
        pcl::getMinMax3D(cloud, cloud_min, cloud_max);

        float width=cloud_max.y-cloud_min.y,  length=cloud_max.x-cloud_min.x;  //内部点云的长度和内部点云的宽度

        inside_err=cloud_max.y+cloud_min.y;   //内部点云的偏离误差
        inside_err=filter_err.GetValue(inside_err);

        inside_left_dis=agv_inside_width*0.5-fabs(cloud_max.y);   //左侧剩余间隔
        inside_right_dis=agv_inside_width*0.5-fabs(cloud_min.y);  //右侧剩余间隔
            
        // ROS_INFO("%.2f %.2f", cloud_max.x, cloud_min.x);  

        if(width>1) agv_in_flag=true;    // 只要有一定宽度点云,就是车进入了

        inside_front_dis=agv_length*0.5-cloud_max.x;       //前方剩余间隔
        inside_back_dis=agv_length*0.5+cloud_min.x;        //后方剩余间隔

        //  判断车整体全部进入
        if(agv_in_flag && length>3.5 && cloud_max.x*cloud_min.x<0 && inside_front_dis>0.1 && inside_back_dis>0.1) 
        {
            agv_all_in_flag=true;     
        }
        // ROS_INFO("%d %.2f %.2f", agv_all_in_flag, inside_front_dis, inside_back_dis);
    }   
}

// 根据前方或后方点云计算横向偏移量,作为纠偏反馈量
float CheckErr(PointCloud cloud)   
{
    float err=999;
    static TDataFilter filter_err(10);

    pcl::PointXYZI cloud_min, cloud_max;
    pcl::getMinMax3D(cloud, cloud_min, cloud_max);
    float obs_dis=fabs(cloud_min.x)-agv_length*0.5;
    if(cloud_min.x<0) obs_dis=fabs(cloud_max.x)-agv_length*0.5; 
    
    float start_pos=obs_dis;
    if(start_pos<0.8)  start_pos=0.8;
    start_pos+=agv_length*0.5;
    
    // printf("%.2f %d\n", obs_dis, cloud.size());

    //把商品车滤波滤出来
    if(cloud_min.x>0)  cloud=Cloud_PassThrough(cloud, start_pos, start_pos+1, -agv_width*0.5, agv_width*0.5, -0.6, 0);
    else cloud=Cloud_PassThrough(cloud, -start_pos-1, -start_pos, -agv_width*0.5, agv_width*0.5, -0.6, 0);

    if(cloud.size()>10) 
    {
        pcl::getMinMax3D(cloud, cloud_min, cloud_max);
            
        float width=cloud_max.y-cloud_min.y,  length=cloud_max.x-cloud_min.x;  //计算点云的宽度和长度
        if(width>1)  
        {
            err=cloud_max.y+cloud_min.y;  //点云的偏差
            err=filter_err.GetValue(err);
            // printf("%.2f\n",err);
        }
    }

    sensor_msgs::PointCloud2 msgx;
    pcl::toROSMsg(cloud, msgx);
    msgx.header.frame_id = cloud.header.frame_id;
    msgx.header.stamp=ros::Time::now();
    pub_cloud_checkerr.publish(msgx);

    return err;   
}

// 前方点云数据的回调函数：获取前方障碍物的距离，根据前方对接商品车纠偏
void PointCloudFrontCallback(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    PointCloud cloud;
    pcl::fromROSMsg(*c_msg, cloud);

    front_err=999;   front_obs_dis=999;
    pcl::PointXYZI cloud_min, cloud_max;

    if(cloud.size()>10)  
    {
        pcl::getMinMax3D(cloud, cloud_min, cloud_max);
        front_obs_dis=fabs(cloud_min.x)-agv_length*0.5;

        if(front_cloud_enable)  front_err=CheckErr(cloud);
    }

    // ROS_INFO("err=%.2f width=%.2f", 0.5*(agv_max.y+agv_min.y), agv_max.y-agv_min.y);
}

// 后方点云数据的回调函数
void PointCloudBackCallback(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    PointCloud cloud;
    pcl::fromROSMsg(*c_msg, cloud);

    back_err=999;   back_obs_dis=999;
    pcl::PointXYZI cloud_min, cloud_max;

    if(cloud.size()>10)  
    {
        pcl::getMinMax3D(cloud, cloud_min, cloud_max);
        back_obs_dis=fabs(cloud_max.x)-agv_length*0.5;
        if(!front_cloud_enable)  back_err=CheckErr(cloud);
    }
}

//  右侧点云数据的回调函数，计算右侧最小距离
void PointCloudRightCallback(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    right_obs_dis=999;
    PointCloud cloud;
    pcl::fromROSMsg(*c_msg, cloud);
    if(cloud.size()<10)  return;

    pcl::PointXYZI cloud_min, cloud_max;
    pcl::getMinMax3D(cloud, cloud_min, cloud_max);
    right_obs_dis=fabs(cloud_max.y)-0.5*agv_width;
}

//  左侧点云数据的回调函数，计算左侧最小距离
void PointCloudLeftCallback(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    left_obs_dis=999;
    PointCloud cloud;
    pcl::fromROSMsg(*c_msg, cloud);
    if(cloud.size()<10)  return;

    pcl::PointXYZI cloud_min, cloud_max;
    pcl::getMinMax3D(cloud, cloud_min, cloud_max);
    left_obs_dis=fabs(cloud_min.y)-0.5*agv_width;
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "cloud_filter");
    ros::NodeHandle nh("~");
    
    // nodecheck = new TNodeCheck(&nh, "node_rate cloudpoint_rate", 1);
    // nodecheck->Find("node_rate")->SetLimit(20);
    // nodecheck->Find("cloudpoint_rate")->SetLimit(10);

    ros::Subscriber cloud_sub1 = nh.subscribe<sensor_msgs::PointCloud2>("/cloud_segmentation/agv_inside_cloud", 10, &PointCloudInsideCallback);   
    ros::Subscriber cloud_sub2 = nh.subscribe<sensor_msgs::PointCloud2>("/cloud_segmentation/agv_back_cloud", 10, &PointCloudBackCallback);   
    ros::Subscriber cloud_sub3 = nh.subscribe<sensor_msgs::PointCloud2>("/cloud_segmentation/agv_front_cloud", 10, &PointCloudFrontCallback);   
    ros::Subscriber cloud_sub4 = nh.subscribe<sensor_msgs::PointCloud2>("/cloud_segmentation/agv_right_cloud", 10, &PointCloudRightCallback);   
    ros::Subscriber cloud_sub5 = nh.subscribe<sensor_msgs::PointCloud2>("/cloud_segmentation/agv_left_cloud", 10, &PointCloudLeftCallback);   
        
    ros::Subscriber task_sub = nh.subscribe<mqtt_comm::task>("/task_cmd", 10, &TaskCallback);  

    ros::Publisher pub_agv_err = nh.advertise<std_msgs::Float32MultiArray>("agv_lidar_err", 10);
    
    ros::Publisher pub_obs_dis = nh.advertise<std_msgs::Float32MultiArray>("obs_dis", 10);
    pub_agv_pose = nh.advertise<geometry_msgs::PoseStamped>("agv_pose", 10);
    pub_cloud_checkerr = nh.advertise<sensor_msgs::PointCloud2>("cloud_checkerr", 10);

    ros::Rate looprate(50);
    while (ros::ok())
    {
        // nodecheck->Find("node_rate")->Beat();

        std_msgs::Float32MultiArray err_msg, obs_msg;

        //  发表纠偏误差
        if(fabs(back_err)<1.5)  err_msg.data.push_back(back_err);
        else err_msg.data.push_back(front_err);
        pub_agv_err.publish(err_msg);

        //  发布前后左右最小距离
        obs_msg.data.push_back(front_obs_dis);
        obs_msg.data.push_back(back_obs_dis);
        obs_msg.data.push_back(left_obs_dis);
        obs_msg.data.push_back(right_obs_dis);
        pub_obs_dis.publish(obs_msg);

        // ROS_INFO("err=%.2f %.2f %.2f  data=%.2f", front_err, inside_err, back_err, err_msg.data[0]);
        // ROS_INFO("obs=%.2f %.2f %.2f %.2f", front_obs_dis, back_obs_dis, left_obs_dis, right_obs_dis);
        // printf("%d\n", agv_in_flag);

        nh.setParam("agv_all_in", agv_all_in_flag);
        nh.setParam("agv_in", agv_in_flag);
                
        ros::spinOnce();
        looprate.sleep();
    }
    ros::shutdown();
    return 0;
};
