#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_ros/transforms.h>
#include <pcl/filters/passthrough.h>
#include <pcl_conversions/pcl_conversions.h>
#include <vector>
#include <algorithm>

using namespace std;

float box_x_min = 0, box_x_max = 5;
float box_y_min = -2, box_y_max = 0;
float box_z_min = -10, box_z_max = 10;
ros::Publisher pub;

pcl::PointCloud<pcl::PointXYZI> cloud1, cloud2;

/**
 * @description: 将输入点云压缩成一维数据(x方向)，排序后聚类，找到最大两簇点云计算距离
 * @param {PointCloud<pcl::PointXYZI>} &cloud_in 输入点云
 * @param {double} distance_thres 聚类阈值
 * @param {int} min_point_size 点云簇最小点云数量
 * @return {double} 距离
 */
double distance(const pcl::PointCloud<pcl::PointXYZI> &cloud_in, const double distance_thres, const int min_point_size)
{
    int size = cloud_in.points.size();
    if (size == 0)
    {
        ROS_ERROR("pointcloud size is 0");
        return -1;
    }

    vector<double> cloud_x(size);
    for (int i = 0; i < size; ++i)
        cloud_x[i] = cloud_in.points[i].x; // 点云压缩方向

    sort(cloud_x.begin(), cloud_x.end());
    // 分段
    vector<pair<int, int>> clusters;
    int pre = 0;
    for (int i = 1; i < size; ++i)
    {
        if (cloud_x[i] - cloud_x[i - 1] > distance_thres)
        {
            if (i - pre > min_point_size) // 过滤杂点
                clusters.push_back(make_pair(pre, i - 1));
            pre = i;
        }
    }
    clusters.push_back(make_pair(pre, size - 1));

    if (clusters.size() <= 1)
        return -1;

    // 找出最大两段
    sort(clusters.begin(), clusters.end(), [](pair<int, int> &a, pair<int, int> &b)
         { return (a.second - a.first) > (b.second - b.first); });
    pair<int, int> part1 = clusters[0], part2 = clusters[1];
    return min(fabs(cloud_x[part2.first] - cloud_x[part1.second]), fabs(cloud_x[part1.first] - cloud_x[part2.second]));
}

pcl::PointCloud<pcl::PointXYZI> Cloud_PassThrough(pcl::PointCloud<pcl::PointXYZI> cp_src)
{
    pcl::PointCloud<pcl::PointXYZI> res;

    pcl::PassThrough<pcl::PointXYZI> pass;
    pass.setInputCloud(cp_src.makeShared());
    pass.setFilterFieldName("z");
    pass.setFilterLimits(box_z_min, box_z_max);
    pass.setFilterLimitsNegative(false);
    pass.filter(res);

    pass.setInputCloud(res.makeShared());
    pass.setFilterFieldName("x");
    pass.setFilterLimits(box_x_min, box_x_max);
    pass.setFilterLimitsNegative(false);
    pass.filter(res);

    pass.setInputCloud(res.makeShared());
    pass.setFilterFieldName("y");
    pass.setFilterLimits(box_y_min, box_y_max);
    pass.setFilterLimitsNegative(false);
    pass.filter(res);

    return res;
}

void PointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    pcl::fromROSMsg(*c_msg, cloud1);
    cloud1 = Cloud_PassThrough(cloud1);
}

void PointCloudCallback2(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    pcl::fromROSMsg(*c_msg, cloud2);
    cloud2 = Cloud_PassThrough(cloud2);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "get_cardistance");
    ros::NodeHandle nh("~");
    ros::Subscriber sub = nh.subscribe<sensor_msgs::PointCloud2>("/cloud_segmentation/agv_front_cloud", 10, &PointCloudCallback);
    ros::Subscriber sub2 = nh.subscribe<sensor_msgs::PointCloud2>("/cloud_segmentation/agv_inside_cloud", 10, &PointCloudCallback2);
    pub = nh.advertise<sensor_msgs::PointCloud2>("cloud", 1);

    ros::Rate looprate(20);
    while (ros::ok())
    {
        ros::spinOnce();
        pcl::PointCloud<pcl::PointXYZI> cloud = cloud1 + cloud2;
        printf("%f\n", distance(cloud, 0.05, 20));
        for (auto &point : cloud.points)
        {
            point.y = 0;
            point.z = 0;
        }
        sensor_msgs::PointCloud2 msgx;
        pcl::toROSMsg(cloud, msgx);
        msgx.header.frame_id = cloud.header.frame_id;
        pub.publish(msgx);
        looprate.sleep();
    }

    return 0;
}