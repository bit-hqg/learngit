//  本节点实现四周多线激光雷达点云转换和分割,输入四路原始点云,经过滤波和坐标变换后,输出前后左右激光点云信号
#define PCL_NO_PRECOMPILE

#include <ros/ros.h>
#include <ros/spinner.h>
#include "std_msgs/String.h"
#include "sensor_msgs/PointCloud2.h"
#include <tf/transform_listener.h>
#include <geometry_msgs/PointStamped.h>
#include "pcl_conversions/pcl_conversions.h"
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/common/common.h>
#include <pcl_ros/transforms.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/filters/voxel_grid.h>
#include <geometry_msgs/PolygonStamped.h>

#include "pointcloud_type.h"
#include "common/public.h"

#include "cloud_preprocess.h"
#include <vector>
#include <algorithm>

using namespace std;

ros::Publisher pub_cloud_front, pub_cloud_inside, pub_cloud_back, pub_cloud_left, pub_cloud_right;
PointCloud cloud[4];

float max_xy_range=20, max_z=-0.1, min_z=-0.6;  
float agv_width=3, agv_length=5.99, agv_inside_width=2.105;  

 //  每个雷达范围滤波和TF变换为base坐标,提高处理速度
void CloudFirst(int id)  
{
    cloud[id] = remove_infinite_points(cloud[id]);
    cloud[id] = Cloud_PassThrough(cloud[id], -max_xy_range, max_xy_range, -max_xy_range, max_xy_range, min_z, max_z);
    // cloud[id] = Cloud_IntensityFilter(cloud[id], 5);
    // cloud[id] = Cloud_RadiusFilter(cloud[id],0.10, 3);
    cloud[id] = CloudTf(cloud[id],"base_link");
}

//  点云组合,范围滤波后分割为前后左右四组点云,发布出去
void cloud_accumulation()     
{
    // printf("%d %d %d %d\n",cloud[0].size(),cloud[1].size(),cloud[2].size(),cloud[3].size());

    for(int i=0;i<4;i++)  if(cloud[i].size()<10) return;
        
    PointCloud all_cloud;
    for(int i=0;i<4;i++)  
    {
        CloudFirst(i); 
        all_cloud+=cloud[i];
        cloud[i].clear();
    }  

    PointCloud inside_cloud = Cloud_PassThrough(all_cloud, -agv_length*0.5, agv_length*0.5, -agv_inside_width*0.5, agv_inside_width*0.5, min_z, max_z);
    inside_cloud=Cloud_RadiusFilter(inside_cloud, 0.05, 3);

    PointCloud front_cloud =  Cloud_PassThrough(all_cloud, agv_length*0.5+0.05, max_xy_range, -agv_width*0.5, agv_width*0.5, min_z, max_z);
    PointCloud back_cloud = Cloud_PassThrough(all_cloud, -max_xy_range, -agv_length*0.5-0.05, -agv_width*0.5, agv_width*0.5, min_z, max_z);
    PointCloud left_cloud =  Cloud_PassThrough(all_cloud, -agv_length*0.5, agv_length*0.5, agv_width*0.5+0.1, max_xy_range, min_z, max_z);
    PointCloud right_cloud =  Cloud_PassThrough(all_cloud, -agv_length*0.5, agv_length*0.5, -max_xy_range, -agv_width*0.5-0.1, min_z, max_z);
    // ROS_INFO("%d", right_cloud.size());

    sensor_msgs::PointCloud2 msgx;
    pcl::toROSMsg(inside_cloud, msgx);
    msgx.header.frame_id = "base_link";
    msgx.header.stamp=ros::Time::now();
    pub_cloud_inside.publish(msgx);

    pcl::toROSMsg(front_cloud, msgx);
    msgx.header.frame_id = "base_link";
    msgx.header.stamp=ros::Time::now();
    pub_cloud_front.publish(msgx);

    pcl::toROSMsg(back_cloud, msgx);
    msgx.header.frame_id = "base_link";
    msgx.header.stamp=ros::Time::now();
    pub_cloud_back.publish(msgx);

    pcl::toROSMsg(left_cloud, msgx);
    msgx.header.frame_id = "base_link";
    msgx.header.stamp=ros::Time::now();
    pub_cloud_left.publish(msgx);

    pcl::toROSMsg(right_cloud, msgx);
    msgx.header.frame_id = "base_link";
    msgx.header.stamp=ros::Time::now();
    pub_cloud_right.publish(msgx);
}

void PointCloudCallback1(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    if(cloud[0].size()>0)  return;
    pcl::fromROSMsg(*c_msg, cloud[0]);
}

void PointCloudCallback2(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    if(cloud[1].size()>0)  return;
    pcl::fromROSMsg(*c_msg, cloud[1]);
}

void PointCloudCallback3(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    if(cloud[2].size()>0)  return;
    pcl::fromROSMsg(*c_msg, cloud[2]);
}

void PointCloudCallback4(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    if(cloud[3].size()>0)  return;
    pcl::fromROSMsg(*c_msg, cloud[3]);
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "cloud_filter");
    ros::NodeHandle nh("~");
    // nodecheck = new TNodeCheck(&nh, "node_rate cloudpoint_rate", 1);
    // nodecheck->Find("node_rate")->SetLimit(20);
    // nodecheck->Find("cloudpoint_rate")->SetLimit(10);

    ros::Subscriber cloud_sub1 = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points1", 10, &PointCloudCallback1);   
    ros::Subscriber cloud_sub2 = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points2", 10, &PointCloudCallback2);   
    ros::Subscriber cloud_sub3 = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points3", 10, &PointCloudCallback3); 
    ros::Subscriber cloud_sub4 = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points4", 10, &PointCloudCallback4); 

    pub_cloud_inside = nh.advertise<sensor_msgs::PointCloud2>("agv_inside_cloud", 10);
    pub_cloud_front = nh.advertise<sensor_msgs::PointCloud2>("agv_front_cloud", 10);
    pub_cloud_back = nh.advertise<sensor_msgs::PointCloud2>("agv_back_cloud", 10);
    pub_cloud_left = nh.advertise<sensor_msgs::PointCloud2>("agv_left_cloud", 10);
    pub_cloud_right = nh.advertise<sensor_msgs::PointCloud2>("agv_right_cloud", 10);

    ros::Rate looprate(20);
    
    // ros::MultiThreadedSpinner spinner(4);
    // spinner.spin();

    while (ros::ok())
    {
        // nodecheck->Find("node_rate")->Beat();
        cloud_accumulation();
                
        ros::spinOnce();
        // spinner.spin();
        looprate.sleep();
    }
    ros::shutdown();
    return 0;
};
