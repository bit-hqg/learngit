//已更改过：将转运机器人本身和地面滤掉（终稿）

#define PCL_NO_PRECOMPILE

#include <ros/ros.h>
#include <ros/spinner.h>
#include "std_msgs/String.h"
#include "sensor_msgs/PointCloud2.h"
#include <tf/transform_listener.h>
#include <geometry_msgs/PointStamped.h>
#include "pcl_conversions/pcl_conversions.h"
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/common/common.h>
#include <pcl_ros/transforms.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/filters/voxel_grid.h>
#include <geometry_msgs/PolygonStamped.h>

#include "pointcloud_type.h"
#include "common/public.h"

#include "cloud_preprocess.h"
#include <vector>
#include <algorithm>

using namespace std;

ros::NodeHandle *nh;
ros::Publisher pub_cloud_front, pub_cloud_inside, pub_cloud_back, pub_cloud_left, pub_cloud_right;
PointCloud cloud[4];

void cloud_accumulation()
{
    // printf("%d %d %d %d\n",cloud[0].size(),cloud[1].size(),cloud[2].size(),cloud[3].size());

    for(int i=0;i<4;i++)  if(cloud[i].size()<10) return;
        
    PointCloud all_cloud;
    for(int i=0;i<4;i++)  all_cloud+=cloud[i],  cloud[i].clear();  

    PointCloud inside_cloud =  Cloud_PassThrough(all_cloud, -2.9, 2.9, -0.88, 0.88, -1, 0.8);
    PointCloud front_cloud =  Cloud_PassThrough(all_cloud, 3.1, 50, -1.5, 1.5, -1, 0.8);
    PointCloud back_cloud =  Cloud_PassThrough(all_cloud, -50, -3.1, -1.5, 1.5, -1, 0.8);
    PointCloud left_cloud =  Cloud_PassThrough(all_cloud, -3, 3, 1.6, 50, -1, 0.8);
    PointCloud right_cloud =  Cloud_PassThrough(all_cloud, -3, 3, -50, -1.6, -1, 0.8);

    // inside_cloud = Cloud_RadiusFilter(inside_cloud, 0.03, 2);
    pcl::PointXYZI agv_min, agv_max, front_min, front_max;
    pcl::getMinMax3D(inside_cloud, agv_min, agv_max);
    pcl::getMinMax3D(front_cloud, front_min, front_max);
    ROS_INFO("err=%.2f len=%.2f dis=%.2f", agv_max.y+agv_min.y, agv_max.x-agv_min.x, front_min.x-agv_max.x);
   
    sensor_msgs::PointCloud2 msgx;
    pcl::toROSMsg(inside_cloud, msgx);
    msgx.header.frame_id = "base_link";
    msgx.header.stamp=ros::Time::now();
    pub_cloud_inside.publish(msgx);

    pcl::toROSMsg(front_cloud, msgx);
    msgx.header.frame_id = "base_link";
    msgx.header.stamp=ros::Time::now();
    pub_cloud_front.publish(msgx);

    pcl::toROSMsg(back_cloud, msgx);
    msgx.header.frame_id = "base_link";
    msgx.header.stamp=ros::Time::now();
    pub_cloud_back.publish(msgx);

    pcl::toROSMsg(left_cloud, msgx);
    msgx.header.frame_id = "base_link";
    msgx.header.stamp=ros::Time::now();
    pub_cloud_left.publish(msgx);

    pcl::toROSMsg(right_cloud, msgx);
    msgx.header.frame_id = "base_link";
    msgx.header.stamp=ros::Time::now();
    pub_cloud_right.publish(msgx);
}

void CloudFirst(int id)
{
    cloud[id] = remove_infinite_points(cloud[id]);
    cloud[id] = Cloud_PassThrough(cloud[id], -50, 50, -50, 50, -1, 0.8);
    // cloud[id] = Cloud_RadiusFilter(cloud[id],0.05, 2);
    cloud[id] = CloudTf(cloud[id],"base_link");
}

void PointCloudCallback1(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    if(cloud[0].size()>0)  return;

    pcl::fromROSMsg(*c_msg, cloud[0]);
    CloudFirst(0);
}

void PointCloudCallback2(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    if(cloud[1].size()>0)  return;
    pcl::fromROSMsg(*c_msg, cloud[1]);
    CloudFirst(1);
}

void PointCloudCallback3(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    if(cloud[2].size()>0)  return;
    pcl::fromROSMsg(*c_msg, cloud[2]);
    CloudFirst(2);
}

void PointCloudCallback4(const sensor_msgs::PointCloud2::ConstPtr &c_msg)
{
    if(cloud[3].size()>0)  return;
    pcl::fromROSMsg(*c_msg, cloud[3]);
    CloudFirst(3);
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "cloud_filter");
    ros::NodeHandle nh("~");
    // nodecheck = new TNodeCheck(&nh, "node_rate cloudpoint_rate", 1);
    // nodecheck->Find("node_rate")->SetLimit(20);
    // nodecheck->Find("cloudpoint_rate")->SetLimit(10);

    ros::Subscriber cloud_sub1 = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points1", 10, &PointCloudCallback1);   
    ros::Subscriber cloud_sub2 = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points2", 10, &PointCloudCallback2);   
    ros::Subscriber cloud_sub3 = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points3", 10, &PointCloudCallback3); 
    ros::Subscriber cloud_sub4 = nh.subscribe<sensor_msgs::PointCloud2>("/rslidar_points4", 10, &PointCloudCallback4); 

    pub_cloud_inside = nh.advertise<sensor_msgs::PointCloud2>("agv_inside_cloud", 10);
    pub_cloud_front = nh.advertise<sensor_msgs::PointCloud2>("agv_front_cloud", 10);
    pub_cloud_back = nh.advertise<sensor_msgs::PointCloud2>("agv_back_cloud", 10);
    pub_cloud_left = nh.advertise<sensor_msgs::PointCloud2>("agv_left_cloud", 10);
    pub_cloud_right = nh.advertise<sensor_msgs::PointCloud2>("agv_right_cloud", 10);

    ros::Rate looprate(50);
    
    // ros::MultiThreadedSpinner spinner(4);
    // spinner.spin();

    while (ros::ok())
    {
        // nodecheck->Find("node_rate")->Beat();

        cloud_accumulation();
                
        ros::spinOnce();
        // spinner.spin();
        looprate.sleep();
    }
    ros::shutdown();
    return 0;
};
